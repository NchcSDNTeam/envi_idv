package org.openflow.nchc.wunyuan;


import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashMap;

import org.openflow.util.LongPair;
import org.pzgui.layout.*;

import edu.uci.ics.jung.graph.Graph;



public class NodeData{
	
	public static HashMap<Long, Point2D> nodePosition = new HashMap<Long, Point2D>();
	
}
