package org.openflow.nchc.wunyuan;

public class ConsoleMessageFrame  {

}
