package org.openflow.nchc.wunyuan;

public class ReadClientData {

	public static boolean dataReadOver = false;

}
